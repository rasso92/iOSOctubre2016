
//
//  Created by estudiante on 11/19/16.
//  Copyright © 2016 estudiante. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FibonacciNumber : NSObject
@property(readonly) int number;
-(id)initWithNumber:(int)number;
@end
